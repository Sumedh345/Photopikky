
// document.getElementById("ggrg").addEventListener("submit",runEvent);
// function runEvent(e){
// if(document.getElementById("hello").value==""){
//   alert("Type something in the Email box below");
// }else{
// console.log("Welome")
// e.preventDefault();
// }};
document.getElementById("hello").addEventListener("focusout",runEvent);
function runEvent(e){
if(document.getElementById("hello").value==""){
  alert("Type something in the Email box below");
  showAlert("Please answer this question");
}else{
console.log("Welome")
e.preventDefault();
}};
Excel.run(function (context) {
  var sheet = context.workbook.worksheets.getItem( JSON.stringify(tasks));
  

  // Get data from the header row


  // Get data from the table
  

  // Get data from a single column
  

  // Get data from a single row


  // Sync to populate proxy objects with data from Excel
  


//In the condition if(document.getElementById("hello").value=="") i didnt give null.I just gave ""because in my main.js i had given
// if(localStorage.getItem(`tasks`)==null){
  //    tasks=[];
      
      
 //   }else{
 //     tasks=JSON.parse(localStorage.getItem(`tasks`));}
 //i had stored array.so if i give null also it would say that it already has a value..so u can give ""..
    