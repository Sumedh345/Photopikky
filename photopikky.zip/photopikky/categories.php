<html>
    <head>
        <link rel="stylesheet" href="style3.css">
        <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    </head>
    <title>categories</title>
    <style>
      .column2{
            float: top;
            width: 90.99%;
            padding: 5;
        }

        * {
          box-sizing: border-box;
        }
        
        .column {
          float:right;
          width: 80.66%;
          
          padding: 310px;
          font-size: x-large;
        
        }
        .row {
        float: top;
        height:19.12;
        padding: 1px; 
        }

    </style>
    <body>
      
    <input type="checkbox" id="check">
          <label for="check">
            <i class="fas fa-bars" id="btn"></i>
            <i class="fas fa-times" id="cancel"></i>
          </label> 
          
            
         <div class="sidebar">
           <header>Categories</header>
         <ul>
      
      <Li><a href="http://localhost/photopikky/main.php"><i class="fas fa-Home"></i>  Menu</a></Li>
      <Li><a href="#"><i class="fas fa-qrcode"></i>  Dashboard  </a></Li>
      <Li><a href="#"><i class="fas fa-question-circle"></i>  Help  </a></Li>
      <Li><a href="#"><i class="fas fa-envelope"></i>  Contact </a></Li>
      <Li><a href="http://localhost/photopikky/Profile.php"><i class="fas fa-user-circle"></i>  Account </a></Li>
    </div>
    <section>
      
    
        <center><font color="red"><h2 class="column2">   Click on</font><font color="blue"> any type of category</h2></center></font>
        <center></i> <button><a href="human.html" class="hello"><i class="fas fa-user-alt"> Humans</i></a> </center></button>
        <center></i> <button><a href="human.html" class="hello2"><i class="fas fa-home"> Houses</i></a> </center></button>
         <center></i> <button><a href="human.html" class="hello3"><i class="fas fa-dog"> Animals</i></a> </center></button>
         <center></i> <button><a href="human.html" class="hello4"><i class="fas fa-table-tennis"> Games</i></a> </center></button>
      </section>
         </body>     
    </ul>
         
</html>