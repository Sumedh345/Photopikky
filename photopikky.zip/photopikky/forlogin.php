<html>
<head>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style2.css"><title>Sign in</title></head>
<FORM ACTION="http://localhost/photopikky/main2.php"METHOD="POST" id="ggrg" class="box" enctype="multipart/form-data">
    
    <style>
        #loading{
            display: none;
        }
        .error {color: #FF0000;}
    </style>
   
 <body>
 


 <table cellpadding=10 cellspacing=10>
              <tr><h1><FONT COLOR="red">Sign in to continue</h1></FONT></tr>
              
    
<td>

<center><div id="grfg"><input type="text"Name="Username"Size="20"minlength="4"  placeholder="Username"oninvalid="this.setCustomValidity('Please type minimum 8 characters')"
    oninput="setCustomValidity('')" title="Please type atleast 8 characters"></FONT></div></center></tr><span class="error">* <?php echo $USERNAMEErr;?></span>
  <br><br>

<Td>
<center><input type="password"Name="password"Size="25" id="password"  placeholder="Password" required ></FONT>
</Tr></center></Tr>


<Td>



</table> 
<table cellpadding=5 cellspacing=5>

    
<script src="Main.js"></script>
</div>




                                                        
<a href="http://localhost/photopikky/account.php" class=login>Click here</a> to create a account

    <Tr>
        <center><input type="submit" name="" value="Sign in"></center>
        </Tr>
       
    </div>
    <script src=app.js></script>
    
</table>
</FORM>
</FONT>
<div class="back"><a style="text-decoration: none"  href="Sumedh.html">Back</a></div>

</body>
</html>


