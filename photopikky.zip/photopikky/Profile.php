<html>
    <head><link rel="stylesheet" href="styleforphp.css"></head><title>Profile</title>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <body><form class="box"><center><h1 class="Profile"><i class="fas fa-user-circle"></i></h1></center>
<h1 class="Username"><center><?php


?></h1></center>
</form></body>
</html>