<?php
include("dbl.php");
if(!mysql_select_db ('play'))
 die(mysql_error);
$r="create table address(Username varchar(20),Email varchar(35),Password(40))";
if(!mysql_query($r))
die("not successfull");
else
echo "Wekcome"
?>

